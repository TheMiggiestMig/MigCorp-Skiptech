# About
MigCorp - Skiptech v1.1.0 made huge changes to the mod.
Part of these changes were the cost and research requirements for skipdoors.

|               | pre-1.1.0           | 1.1.0+                |
|---------------|---------------------|-----------------------|
| Research      | Multianalyzer       | Fabrication + SkipNet |
| Plasteel      |100                  |75                     |
| Component     |5                    |4                      |
| Adv. Component|1                    |1                      |
| Uranium       |50                   |-                      |
| Skip Beacon   |-                    |1                      |

These changes were made for balance reasons, in order to prevent early
skipdoor spam that makes progression meaningless.

This patch rolls back those balance changes, while allowing the rest of the updates through.

# How to use
1. Copy the contents of this folder into `C:\Program Files (x86)\Steam\steamapps\common\RimWorld\Mods\migcorp-skiptech-bootleg-patch` (or wherever your RimWorld mods folder is)
2. Add `MigCorp - Skiptech (Legacy Skipdoors)` to your mod list, and make sure it loads **after** `MigCorp - Skiptech`.
3. Enjoy the cheaper MigCorp Skipdoors, with all the up-to-date features!

# Warranty
MigCorp - Skiptech can change at any point in a way that is incompatible with this patch. Use at own risk!